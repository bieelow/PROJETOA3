package com.gestaoprojetos.controllers;

import com.gestaoprojetos.models.Projeto;
import com.gestaoprojetos.repositories.ProjetoRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class RelatorioController {

    private final ProjetoRepository projetoRepo;

    public RelatorioController(ProjetoRepository projetoRepo) { this.projetoRepo = projetoRepo; }

    @GetMapping("/relatorios")
    public String relatorios(Model model) {
        List<Projeto> projetos = projetoRepo.findAll();
        Map<String, List<Projeto>> porStatus = projetos.stream().collect(Collectors.groupingBy(p -> p.getStatus() == null ? "SEM STATUS" : p.getStatus()));
        model.addAttribute("porStatus", porStatus);
        return "relatorios";
    }
}
