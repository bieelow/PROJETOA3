package com.gestaoprojetos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoProjetosApplicationTests {

    @Test
    void contextLoads() {
        // Verifica se a aplicação sobe sem erros
    }
}
