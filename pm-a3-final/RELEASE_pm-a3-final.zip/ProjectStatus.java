package com.faculana.pm.domain;
/** Status simples do projeto (enum). */
public enum ProjectStatus { PLANEJADO, EM_ANDAMENTO, CONCLUIDO, CANCELADO }
