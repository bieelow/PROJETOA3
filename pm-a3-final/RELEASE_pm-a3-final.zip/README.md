Tecnologias (poucas) e por quê:

Java 21 + Spring Boot 3.x: padrão de mercado, sobe servidor embutido, reduz configuração manual.

Spring Web + Thymeleaf: REST simples e páginas mínimas sem frameworks extras.

Spring Data JPA + H2: BD relacional em memória para correção rápida (zero setup).

JUnit 5 (Mockito incluso no starter): testes unitários e integração leves, sem dependências extras.

Como rodar em 3 passos:

mvn -q test (roda testes unitários e integração leve).

mvn -q -DskipTests package (empacota).

mvn spring-boot:run e abrir http://localhost:8080/ e /projects.

Onde cada requisito da A3 está no código:

POO (entidades/enum/associações): domain/ (Project, Task, Team, User, ProjectStatus).

Exceções/handler: web/ (NotFoundException, GlobalExceptionHandler).

Pilha/Fila/Ordenação/Busca: util/algoritmos/ + endpoints demo em /api/demo/... e /api/tasks/sort|search.

BD relacional: JPA + H2 (application.yml).

UI mínima: templates/home.html e templates/projects.html.

Testes: src/test/... (algoritmos, service com Mockito e repositório com H2).

Observação: se a banca exigir MySQL, criar apenas src/main/resources/application-mysql.yml com URL/credenciais e usar --spring.profiles.active=mysql. Não criar Docker/Compose.

Como testar via .http: Abra `docs/ROTAS.http` no VS Code e clique em "Send Request" em cada bloco.

Executável jar (opcional): java -jar target/pm-a3-final-0.0.1-SNAPSHOT.jar
