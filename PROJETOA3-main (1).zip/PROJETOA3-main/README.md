# PROJETOA3
Projeto desenvolvido como parte da disciplina de Programação de Soluções Computacionais, utilizando Spring Boot, Hibernate e H2 para gerenciamento de projetos, com autenticação e autorização via Spring Security. Inclui funcionalidades de cadastro de usuários e acesso ao console H2 para testes.
